import os
os.system('rm -rf gen*')
os.system('rm stats.txt')
